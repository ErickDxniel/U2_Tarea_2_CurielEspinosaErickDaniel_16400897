package mx.tecnm.tepic.ladm_u2_ejercicio1_timerhilos

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.Exception

class MainActivity : AppCompatActivity() {
    var contadorTimer = 0

    var contadorHilo = 0
    val LAPSO = 500 // 2000 milisegundos = 2 segundos
    val TIEMPOTOTAL =  20000 // 20000 milisegundos = 20 minutos
    var hilito = Hilo(this)
    //Sintaxis del Time, TIEMPO TOTAL y LAPSO en MILISGEGUNDOS
    //var timer : String ?= null declaracion normal en kotlin
    var timer = object : CountDownTimer(TIEMPOTOTAL.toLong(), LAPSO.toLong()){
        override fun onTick(millisUntilFinished: Long) {
            /*
            onTick = Se ejecuta cuando el tiempo "Lapso" llega a ser 0
             */
            contadorTimer++
            textView2.text = "Timer: ${contadorTimer}"
        }

        override fun onFinish() {
            /*
            onFinisih = Se ejecuta cuando el tiempo "Total" se hace 0
            una vez que se ejecuta el onFinish el Timer SE DETIENE, a MENOS
            que se invoque un START dentro del onFinish, empezando de nuevo
             */
            start()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        button2.setOnClickListener {
            timer.start()
        }



        button2.setOnClickListener {
            try {
                hilito.start()//Hago que el objeto hilito, construido a partir de la clase Hilo se ejecute en segundo plano
            }catch(e:Exception){
                AlertDialog.Builder(this)
                    .setMessage("El Hilo No Se Puede Volver A Ejecutar ")
                    .setTitle("Atención")
                    .setPositiveButton("ok"){d, i-> 0}
            }
        }

        button3.setOnClickListener {
            hilito.pausar()
        }

        button4.setOnClickListener {
            hilito.terminarHilo()
        }
        button5.setOnClickListener {
            hilito.reiniciar()
        }
    }
}

//  Crear la CLASE HILO
class Hilo(p:MainActivity) :Thread(){
    var puntero = p
    var mantener = true
    var despausado = true
    var reinicio = false

    fun  terminarHilo(){
        mantener = false
    }

    fun pausar(){
        despausado = !despausado
    }

    fun reiniciar (){
        reinicio = true
    }//reinicio

    override fun run(){
        super.run()
        /*
         es el metodo que funciona similar al onTick es decir, esta siempre el tiempo
         eb ejecución, siempre se cicla.
         Realmente run solo se ejecuta 1 vez en 2do plano.
         */
        while(mantener) {
            //ciclo infinito que permite mantener al RUN en ejecución Permanente en 2do plano
            if (despausado==true) {
                puntero.contadorHilo++
                puntero.runOnUiThread {
                    /*se debe usar el runOnUiThread debido a que, la Interfaz
                grafica le pertenece al mainActivity, y Kotlin no permite de manera
                directa  otra clase modifique una interfaz grafica que no le pertenece
                la otra clase se entiende que es el Hilo. Por ello usamos el bloque
                runOnUiThread.
                */
                    puntero.textView2.text = "" + puntero.contadorHilo
                }//runOnUiThread
                    if (reinicio){
                        puntero.contadorHilo = 0
                        reinicio = false
                    }
            }
            //AL HILO LE AFECTA EL STRESS
            sleep(500)
        }
        //Corrutinas CLASE DEPRECIADA = AsyncTask (obsoleta)
    }
}